var app = angular.module('phoneApp',[]);
app.controller('phoneController',['$scope', function($scope){
	$scope.phones = [
		{
		   id: 1,
		   name: "HONOR 8X 128GB 4G DUAL SIM, red ",
		   icon: "honor_8x.jpg",
		   brand: "HONOR",
		   variant: "Red",
		   price: 19047
		},
		{
		   id: 2,
		   name: "APPLE IPHONE XR, coral, 256gb",
		   icon: "iphone_xr.jpg",
		   brand: "APPLE",
		   variant: "Coral",
		   price: 68800
		},
		{
		   id: 3,
		   name: "HUAWEI P20 PRO 128GB DUAL SIM,  purple",
		   icon: "huwai_p20.jpg",
		   brand: "HUAWEI",
		   variant: "Purple",
		   price: 41915
		}
	];
	$scope.cartDetails = [];
	$scope.addToCart = function(index){

		$("#shoppingCart").css('width', "25%");
		$(".overlay").css('display',"block");
		var cartIndex = $scope.cartDetails.indexOf($scope.phones[index]);
		if (cartIndex>=0){
			$scope.cartDetails[cartDetails].count +=1;
		}
		else{
			$scope.cartDetails.push($scope.phones[index]);
			$scope.cartDetails[$scope.cartDetails.length-1].count = 1;
		}
	};

	$scope.removeFromCart = function(index){
		$scope.cartDetails.splice(index, 1);
	}
}]);
